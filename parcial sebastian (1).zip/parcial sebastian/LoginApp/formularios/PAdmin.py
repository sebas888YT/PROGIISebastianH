import tkinter as tk
import json
from tkinter import messagebox, ttk
import util.generic as utl
class PAdmin(tk.Tk):
    def __init__(self, name="", username="", email=""):
        self.name = name
        self.username = username
        self.email = email
        self.tipo_action ="Guardar"
        self.tipo_user = ""
        super().__init__()
        self.title("Panel Administrativo")
        self.resizable(False, False)
        # Obtener las dimensiones de la pantalla
        self.ancho_pantalla = self.winfo_screenwidth() 
        self.alto_pantalla = self.winfo_screenheight() 

        # Establecer el tamaño completo de la ventana
        self.geometry(f"{self.ancho_pantalla}x{self.alto_pantalla}")
        
        menubar = tk.Menu(self)  
        menuuser = tk.Menu(menubar, tearoff=0)  
        menuuser.add_command(label="Administracion de Usuarios", command=self.main_usuarios)  
        menubar.add_cascade(label="Usuarios", menu=menuuser)  

        menuclientes = tk.Menu(menubar, tearoff=0)
        menuclientes.add_command(label="Administracion de Cliente", command=self.main_clientes)  
        menubar.add_cascade(label="Clientes", menu=menuclientes)

        menucategorias = tk.Menu(menubar, tearoff=0)
        menucategorias.add_command(label="Administracion de Animales", command=self.main_animales)   
        menubar.add_cascade(label="Animales", menu=menucategorias)   

        menuproducto = tk.Menu(menubar, tearoff=0)
        menuproducto.add_command(label="Administracion de TIpos", command=self.main_tipos)    
        menubar.add_cascade(label="Tipos", menu=menuproducto)

        menuventas = tk.Menu(menubar, tearoff=0)
        menuventas.add_command(label="Administracion de Atenciones", command=self.main_atenciones)
        menubar.add_cascade(label="Atenciones", menu=menuventas)

        self.config(menu=menubar)

        # frame user_info

        self.frame_user_info = tk.Frame(self, bd=0,relief=tk.SOLID, width=200)
        self.frame_user_info.pack(side=tk.LEFT, padx=4, pady=5,fill="y")
        texto=tk.Label(self.frame_user_info, text="PANEL ADMINISTRATIVO", font=('Times', 20))
        texto.pack(padx=20,pady=4)
        self.usrimg = utl.leer_imagen(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\imagenes\userinfo.png", (128, 128))

        tk.Label(self.frame_user_info,image=self.usrimg).pack(padx=30,pady=4)
        tk.Label(self.frame_user_info, text=self.name, font=('Times', 14)).pack(padx=40,pady=4)
        tk.Label(self.frame_user_info, text=self.email, font=('Times', 14)).pack(padx=50,pady=4)

        
        #frame_data
        
        self.frame_data = tk.Frame(self, bd=0,relief=tk.SOLID, width=f"{self.ancho_pantalla-200}")
        self.frame_data.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)
        textobienvenida=tk.Label(self.frame_data, text="BIENVENIDO AL SISTEMA", font=('Times', 20))
        textobienvenida.pack(padx=20,pady=4)

        #frame_dinamyc
        self.frame_dinamyc = tk.Frame(self.frame_data, bd=0,relief=tk.SOLID, width=f"{self.ancho_pantalla-200}")
        self.frame_dinamyc.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)

    def main_usuarios(self):
        self.formulario_usuario()
        self.listar_usuarios()
    
    def formulario_usuario(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="\uf0c9 REGISTRO DE USUARIOS", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=30)
        
        labelcedula = tk.Label(self.frame_dinamyc,text="Cedula:", font=('Times',14))
        labelcedula.place(x=70, y=100)
        self.ccedula = tk.Entry(self.frame_dinamyc, width=40)
        self.ccedula.place(x=220, y=100)

        labelnombre = tk.Label(self.frame_dinamyc,text="Nombre completo:", font=('Times',14))
        labelnombre.place(x=70, y=130)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=40)
        self.cnombre.place(x=220, y=130)

        labelusuario = tk.Label(self.frame_dinamyc,text="Username:", font=('Times',14))
        labelusuario.place(x=70,y=160)
        self.cusuario = tk.Entry(self.frame_dinamyc, width=40)
        self.cusuario.place(x=220,y=160)

        labelclave = tk.Label(self.frame_dinamyc,text="Contraseña:", font=('Times',14))
        labelclave.place(x=500,y=100)
        self.cclave = tk.Entry(self.frame_dinamyc, width=40, show="*")
        self.cclave.place(x=600, y=100)

        labelcorreo = tk.Label(self.frame_dinamyc,text="Correo:", font=('Times',14))
        labelcorreo.place(x=500,y=130)
        self.ccorreo = tk.Entry(self.frame_dinamyc, width=40)
        self.ccorreo.place(x=600, y=130)

        labeltipo = tk.Label(self.frame_dinamyc, text="Rol:", font=('Times',14))
        labeltipo.place(x=500,y=160)
        self.listatipo = tk.Listbox(self.frame_dinamyc, selectmode="Single", width=40, height=2)
        self.listatipo.place(x=600,y=160)
        self.listatipo.insert(1, "Administrador")
        self.listatipo.insert(2, "Vendedor")

        btnguardar = tk.Button(self.frame_dinamyc, text="\uf0c7 GUARDAR", font=('Times',14), command=self.save_user)
        btnguardar.place(x=870, y=130)
    
    def listar_usuarios(self):
        tk.Label(self.frame_dinamyc,text="\uf00b LISTADO DE USUARIOS", font=('Times',16),fg="#9fa8da").place(x=70, y=200)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("NombreCompleto", "Username", "Email", "Rol"))
        self.tablausuarios.heading("#0", text="Cedula")
        self.tablausuarios.heading("NombreCompleto", text="Nombre Completo")
        self.tablausuarios.heading("Username", text="Usuario")
        self.tablausuarios.heading("Email", text="Email")
        self.tablausuarios.heading("Rol", text="Rol")
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\db_users.json", "r", encoding='utf-8') as self.file:
                self.db_users = json.load(self.file)
                for usuarios in self.db_users["users"]:
                    self.tablausuarios.insert("", "end", text=f'{usuarios["id"]}',values=(f'{usuarios["name"]}',f'{usuarios["username"]}',f'{usuarios["email"]}', f'{usuarios["role"]}'))
        self.tablausuarios.place(x=70, y=250)
        btneliminar = tk.Button(self.frame_dinamyc, text="\uf0c7 Eliminar", font=('Times',14), command=self.delete_user)
        btneliminar.place(x=70, y=520)
        btnupdate = tk.Button(self.frame_dinamyc, text="\uf0c7 Actualizar", font=('Times',14), command=self.update_user)
        btnupdate.place(x=200, y=520)

    def save_user(self):
        for index in self.listatipo.curselection():
            self.tipo_user = self.listatipo.get(index)
        if self.ccedula.get() =="" or self.cnombre.get() == "" or self.cusuario.get() == "" or self.ccorreo.get() == "" or self.cclave.get() == "" :
            messagebox.showinfo('Info',"Debe llenar todos los campos",parent=self)
            return 
        else:
                with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\db_users.json", "r", encoding='utf-8') as self.file:
                        self.db_users = json.load(self.file)

                        if self.tipo_action == "Actualizar":

                            for usuarios in self.db_users["users"]:
                                if usuarios["id"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                                    usuarios["id"] = self.ccedula.get()
                                    usuarios["name"] = self.cnombre.get()
                                    usuarios["username"] = self.cusuario.get()
                                    usuarios["password"] =  self.cclave.get()
                                    usuarios["email"] = self.ccorreo.get()
                                    usuarios["role"] = self.tipo_user
                                    with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\db_users.json", 'w') as jf: 
                                        json.dump(self.db_users, jf, indent=4, ensure_ascii=True)
                                        messagebox.showinfo('Info',"Usuario actualizado con exito",parent=self)
                                        #self.listar_usuarios()
                                        self.limpiar_panel(self.frame_dinamyc)
                    
                        else:
                            self.db_users["users"].append({
                                            'id': self.ccedula.get(),
                                            'name': self.cnombre.get(),
                                            'username': self.cusuario.get(),
                                            'password': self.cclave.get(),
                                            'email': self.ccorreo.get(),
                                            'role':self.tipo_user
                                            })
                            with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\db_users.json", 'w') as jf: 
                                json.dump(self.db_users, jf, indent=4, ensure_ascii=True)
                                messagebox.showinfo('Info',"Usuario registrado con exito",parent=self)
                                self.limpiar_panel(self.frame_dinamyc) 


    def delete_user(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\db_users.json", "r", encoding='utf-8') as self.file:
                self.db_users = json.load(self.file)
                for usuarios in self.db_users["users"]:
                    if usuarios["id"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                        self.db_users["users"].remove(usuarios)
                        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\db_users.json", 'w') as jf:
                            json.dump(self.db_users, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Usuario eliminado con exito",parent=self)
                            self.limpiar_panel(self.frame_dinamyc)
                            break



    def update_user(self):
                with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\db_users.json", "r", encoding='utf-8') as self.file:
                    self.db_users = json.load(self.file)

                seleccion = self.tablausuarios.selection()

                if seleccion:

                    for item in seleccion:
                        itemm = self.tablausuarios.index(item)
                        
                        self.ccedula.delete(0, tk.END)
                        self.ccedula.insert(0, self.db_users["users"][itemm]["id"])

                        self.cnombre.delete(0, tk.END)
                        self.cnombre.insert(0, self.db_users["users"][itemm]["name"])

                        self.cusuario.delete(0, tk.END)
                        self.cusuario.insert(0, self.db_users["users"][itemm]["username"])

                        self.cclave.delete(0, tk.END)
                        self.cclave.insert(0, self.db_users["users"][itemm]["password"])

                        self.ccorreo.delete(0, tk.END)
                        self.ccorreo.insert(0, self.db_users["users"][itemm]["email"])

                        self.listatipo.delete(0, tk.END)
                        self.listatipo.insert(0, self.db_users["users"][itemm]["role"])

                        self.tipo_action = "Actualizar"
                        break


#### frame clientes ######

    def main_clientes(self):
        self.formulario_cliente()
        self.listar_cliente()
    
    def formulario_cliente(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="\uf0c9 REGISTRO DE CLIENTES", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=30)
        
        labelcedula = tk.Label(self.frame_dinamyc,text="Cedula:", font=('Times',14))
        labelcedula.place(x=70, y=100)
        self.ccedula = tk.Entry(self.frame_dinamyc, width=40)
        self.ccedula.place(x=220, y=100)

        labelnombre = tk.Label(self.frame_dinamyc,text="Nombre completo:", font=('Times',14))
        labelnombre.place(x=70, y=130)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=40)
        self.cnombre.place(x=220, y=130)

        labelusuario = tk.Label(self.frame_dinamyc,text="Username:", font=('Times',14))
        labelusuario.place(x=70,y=160)
        self.cusuario = tk.Entry(self.frame_dinamyc, width=40)
        self.cusuario.place(x=220,y=160)

        labelclave = tk.Label(self.frame_dinamyc,text="Contraseña:", font=('Times',14))
        labelclave.place(x=500,y=100)
        self.cclave = tk.Entry(self.frame_dinamyc, width=40, show="*")
        self.cclave.place(x=600, y=100)

        labelcorreo = tk.Label(self.frame_dinamyc,text="Correo:", font=('Times',14))
        labelcorreo.place(x=500,y=130)
        self.ccorreo = tk.Entry(self.frame_dinamyc, width=40)
        self.ccorreo.place(x=600, y=130)

        btnguardar = tk.Button(self.frame_dinamyc, text="\uf0c7 GUARDAR", font=('Times',14), command=self.save_cliente)
        btnguardar.place(x=870, y=130)
    
    def listar_cliente(self):
        tk.Label(self.frame_dinamyc,text="\uf00b LISTADO DE CLIENTES", font=('Times',16),fg="#9fa8da").place(x=70, y=200)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("NombreCompleto", "Username", "Email"))
        self.tablausuarios.heading("#0", text="Cedula")
        self.tablausuarios.heading("NombreCompleto", text="Nombre Completo")
        self.tablausuarios.heading("Username", text="Usuario")
        self.tablausuarios.heading("Email", text="Email")
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\clientes.json", "r", encoding='utf-8') as self.file:
                self.clientes = json.load(self.file)
                for clientes in self.clientes["clientes"]:
                    self.tablausuarios.insert("", "end", text=f'{clientes["id"]}',values=(f'{clientes["name"]}',f'{clientes["username"]}',f'{clientes["email"]}'))
        self.tablausuarios.place(x=70, y=250)
        btneliminar = tk.Button(self.frame_dinamyc, text="\uf0c7 Eliminar", font=('Times',14), command=self.delete_cliente)
        btneliminar.place(x=70, y=520)
        btnupdate = tk.Button(self.frame_dinamyc, text="\uf0c7 Actualizar", font=('Times',14), command=self.update_cliente)
        btnupdate.place(x=200, y=520)

    def save_cliente(self):
        if self.ccedula.get() =="" or self.cnombre.get() == "" or self.cusuario.get() == "" or self.ccorreo.get() == "" or self.cclave.get() == "" :
            messagebox.showinfo('Info',"Debe llenar todos los campos",parent=self)
            return 
        else:
                with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\clientes.json", "r", encoding='utf-8') as self.file:
                        self.clientes = json.load(self.file)

                        if self.tipo_action == "Actualizar":

                            for clientes in self.clientes["clientes"]:
                                if clientes["id"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                                    clientes["name"] = self.cnombre.get()
                                    clientes["username"] = self.cusuario.get()
                                    clientes["password"] =  self.cclave.get()
                                    clientes["email"] = self.ccorreo.get()
                                    with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\clientes.json", 'w') as jf: 
                                        json.dump(self.clientes, jf, indent=4, ensure_ascii=True)
                                        messagebox.showinfo('Info',"Cliente actualizado con exito",parent=self)
                                        #self.listar_usuarios()
                                        self.limpiar_panel(self.frame_dinamyc)
                    
                        else:
                            self.clientes["clientes"].append({
                                            'id': self.ccedula.get(),
                                            'name': self.cnombre.get(),
                                            'username': self.cusuario.get(),
                                            'password': self.cclave.get(),
                                            'email': self.ccorreo.get()
                                        
                                            })
                            with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\clientes.json", 'w') as jf: 
                                json.dump(self.clientes, jf, indent=4, ensure_ascii=True)
                                messagebox.showinfo('Info',"Cliente registrado con exito",parent=self)
                                self.limpiar_panel(self.frame_dinamyc) 


    def delete_cliente(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\clientes.json", "r", encoding='utf-8') as self.file:
                self.clientes = json.load(self.file)
                for clientes in self.clientes["clientes"]:
                    if clientes["id"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                        self.clientes["clientes"].remove(clientes)
                        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\clientes.json", 'w') as jf:
                            json.dump(self.clientes, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Cliente eliminado con exito",parent=self)
                            self.limpiar_panel(self.frame_dinamyc)
                            break



    def update_cliente(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\clientes.json", "r", encoding='utf-8') as self.file:
                self.clientes = json.load(self.file)

                seleccion = self.tablausuarios.selection()

                if seleccion:

                    for item in seleccion:
                        itemm = self.tablausuarios.index(item)

                        self.ccedula.delete(0, tk.END)
                        self.ccedula.insert(0, self.clientes["clientes"][itemm]["id"])
                        self.cnombre.delete(0, tk.END)
                        self.cnombre.insert(0, self.clientes["clientes"][itemm]["name"])
                        self.cusuario.delete(0, tk.END)
                        self.cusuario.insert(0,self.clientes["clientes"][itemm]["username"])
                        self.cclave.delete(0, tk.END)
                        self.cclave.insert(0, self.clientes["clientes"][itemm]["password"])
                        self.ccorreo.delete(0, tk.END)
                        self.ccorreo.insert(0, self.clientes["clientes"][itemm]["email"])
                        self.tipo_action = "Actualizar"


### Animales ####

    def main_animales(self):
        self.formulario_animales()
        self.listar_animales()
    
    def formulario_animales(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="\uf0c9 REGISTRO DE ANIMALES", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=30)
        
        labelpropietario = tk.Label(self.frame_dinamyc,text="Propietario:", font=('Times',14))
        labelpropietario.place(x=70, y=100)
        self.propietario = tk.Entry(self.frame_dinamyc, width=40)
        self.propietario.place(x=220, y=100)

        labelnombre = tk.Label(self.frame_dinamyc,text="Nombre completo:", font=('Times',14))
        labelnombre.place(x=70, y=130)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=40)
        self.cnombre.place(x=220, y=130)

        labeledad = tk.Label(self.frame_dinamyc,text="Edad:", font=('Times',14))
        labeledad.place(x=70,y=160)
        self.edad = tk.Entry(self.frame_dinamyc, width=40)
        self.edad.place(x=220,y=160)

        labelraza = tk.Label(self.frame_dinamyc,text="Raza:", font=('Times',14))
        labelraza.place(x=500,y=100)
        self.raza = tk.Entry(self.frame_dinamyc, width=40)
        self.raza.place(x=600, y=100)

        btnguardar = tk.Button(self.frame_dinamyc, text="\uf0c7 GUARDAR", font=('Times',14), command=self.save_animales)
        btnguardar.place(x=600, y=130)
    
    def listar_animales(self):
        tk.Label(self.frame_dinamyc,text="\uf00b LISTADO DE ANIMALES", font=('Times',16),fg="#9fa8da").place(x=70, y=200)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("NombreCompleto", "Edad", "Raza"))
        self.tablausuarios.heading("#0", text="Propietario")
        self.tablausuarios.heading("NombreCompleto", text="Nombre Completo")
        self.tablausuarios.heading("Edad", text="Edad")
        self.tablausuarios.heading("Raza", text="Raza")
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json", "r", encoding='utf-8') as self.file:
                self.animales = json.load(self.file)
                for animales in self.animales["animales"]:
                    self.tablausuarios.insert("", "end", text=f'{animales["propietario"]}',values=(f'{animales["nombre"]}',f'{animales["edad"]}',f'{animales["raza"]}'))
        self.tablausuarios.place(x=70, y=250)
        btneliminar = tk.Button(self.frame_dinamyc, text="\uf0c7 Eliminar", font=('Times',14), command=self.delete_animales)
        btneliminar.place(x=70, y=520)
        btnupdate = tk.Button(self.frame_dinamyc, text="\uf0c7 Actualizar", font=('Times',14), command=self.update_animales)
        btnupdate.place(x=200, y=520)

    def save_animales(self):
        if self.propietario.get() =="" or self.cnombre.get() == "" or self.edad.get() == "" or self.raza.get() == "" :
            messagebox.showinfo('Info',"Debe llenar todos los campos",parent=self)
            return 
        else:
                with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json", "r", encoding='utf-8') as self.file:
                        self.animales = json.load(self.file)

                        if self.tipo_action == "Actualizar":

                            for animales in self.animales["animales"]:
                                if animales["propietario"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                                    animales["propietario"] = self.propietario.get()
                                    animales["nombre"] = self.cnombre.get()
                                    animales["edad"] = self.edad.get()
                                    animales["raza"] =  self.raza.get()
                                    
                                    with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json", 'w') as jf: 
                                        json.dump(self.animales, jf, indent=4, ensure_ascii=True)
                                        messagebox.showinfo('Info',"Animal actualizado con exito",parent=self)
                                        #self.listar_usuarios()
                                        self.limpiar_panel(self.frame_dinamyc)
                    
                        else:
                            self.animales["animales"].append({
                                            'propietario': self.propietario.get(),
                                            'nombre': self.cnombre.get(),
                                            'edad': self.edad.get(),
                                            'raza': self.raza.get()
                                            
                                        
                                            })
                            with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json", 'w') as jf: 
                                json.dump(self.animales, jf, indent=4, ensure_ascii=True)
                                messagebox.showinfo('Info',"Animal registrado con exito",parent=self)
                                self.limpiar_panel(self.frame_dinamyc) 


    def delete_animales(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json", "r", encoding='utf-8') as self.file:
                self.animales = json.load(self.file)
                for animales in self.animales["animales"]:
                    if animales["propietario"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                        self.animales["animales"].remove(animales)
                        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json", 'w') as jf:
                            json.dump(self.animales, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Animal eliminado con exito",parent=self)
                            self.limpiar_panel(self.frame_dinamyc)
                            break



    def update_animales(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json", "r", encoding='utf-8') as self.file:
                self.animales = json.load(self.file)


                for animales in self.animales["animales"]:
                    if animales["propietario"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                        self.propietario.delete(0, tk.END)
                        self.propietario.insert(0, animales["propietario"])
                        self.cnombre.delete(0, tk.END)
                        self.cnombre.insert(0,animales["nombre"])
                        self.edad.delete(0, tk.END)
                        self.edad.insert(0,animales["edad"])
                        self.raza.delete(0, tk.END)
                        self.raza.insert(0,animales["raza"])
                        self.tipo_action = "Actualizar"

## tipos ###

    def main_tipos(self):
        self.formulario_tipos()
        self.listar_tipos()

    def clientes_e(self, event):
        animal = self.cliente_e.get()
        
    
    def formulario_tipos(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="\uf0c9 REGISTRO DE TIPOS", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=30)
        
        labelcliente = tk.Label(self.frame_dinamyc,text="Cliente:", font=('Times',14))
        labelcliente.place(x=70, y=100)

        with open(r'C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json', 'r') as jf:
            animales = json.load(jf)

        Animales = [animal["nombre"] for animal in animales["animales"]]

        self.cliente_e = ttk.Combobox(self.frame_dinamyc,
                                        
            values= Animales
        )
        self.cliente_e.place(x= 270, y=100)
        self.cliente_e.bind("<<ComboboxSelected>>", self.clientes_e)

        labeltipo = tk.Label(self.frame_dinamyc,text="Tipo de Animal:", font=('Times',14))
        labeltipo.place(x=70, y=130)
        self.tipo = tk.Entry(self.frame_dinamyc, width=40)
        self.tipo.place(x=270, y=130)

        labedescripcion = tk.Label(self.frame_dinamyc,text="Descripcion detallada:", font=('Times',14))
        labedescripcion.place(x=70,y=160)
        self.descripcion = tk.Entry(self.frame_dinamyc, width=40)
        self.descripcion.place(x=270,y=160)


        btnguardar = tk.Button(self.frame_dinamyc, text="\uf0c7 GUARDAR", font=('Times',14), command=self.save_tipos)
        btnguardar.place(x=600, y=130)
    
    def listar_tipos(self):
        tk.Label(self.frame_dinamyc,text="\uf00b LISTADO DE TIPOS", font=('Times',16),fg="#9fa8da").place(x=70, y=200)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("Tipo", "Descripcion"))
        self.tablausuarios.heading("#0", text="Cliente")
        self.tablausuarios.heading("Tipo", text="Tipo")
        self.tablausuarios.heading("Descripcion", text="Descripcion")
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\tipos.json", "r", encoding='utf-8') as self.file:
                self.tipos = json.load(self.file)
                for tipos in self.tipos["tipos"]:
                    self.tablausuarios.insert("", "end", text=f'{tipos["cliente"]}',values=(f'{tipos["tipo"]}',f'{tipos["descripcion"]}'))
        self.tablausuarios.place(x=70, y=250)
        btneliminar = tk.Button(self.frame_dinamyc, text="\uf0c7 Eliminar", font=('Times',14), command=self.delete_tipos)
        btneliminar.place(x=70, y=520)
        btnupdate = tk.Button(self.frame_dinamyc, text="\uf0c7 Actualizar", font=('Times',14), command=self.update_tipos)
        btnupdate.place(x=200, y=520)

    def save_tipos(self):
        if self.cliente_e.get() =="" or self.tipo == "" or self.descripcion == "" :
            messagebox.showinfo('Info',"Debe llenar todos los campos",parent=self)
            return 
        else:
                with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\tipos.json", "r", encoding='utf-8') as self.file:
                        self.tipos = json.load(self.file)

                        if self.tipo_action == "Actualizar":

                            for tipos in self.tipos["tipos"]:
                                if tipos["cliente"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                                    tipos["cliente"] = self.cliente_e.get()
                                    tipos["tipo"] = self.tipo.get()
                                    tipos["descripcion"] = self.descripcion.get()
                                    
                                    
                                    with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\tipos.json", 'w') as jf: 
                                        json.dump(self.tipos, jf, indent=4, ensure_ascii=True)
                                        messagebox.showinfo('Info',"Tipo actualizado con exito",parent=self)
                            
                                        self.limpiar_panel(self.frame_dinamyc)
                    
                        else:
                            self.tipos["tipos"].append({
                                            'cliente': self.cliente_e.get(),
                                            'tipo': self.tipo.get(),
                                            'descripcion': self.descripcion.get(),
                                            
                                        
                                            })
                            with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\tipos.json", 'w') as jf: 
                                json.dump(self.tipos, jf, indent=4, ensure_ascii=True)
                                messagebox.showinfo('Info',"Tipo registrado con exito",parent=self)
                                self.limpiar_panel(self.frame_dinamyc) 


    def delete_tipos(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\tipos.json", "r", encoding='utf-8') as self.file:
                self.tipos = json.load(self.file)
                for tipos in self.tipos["tipos"]:
                    if tipos["cliente"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                        self.tipos["tipos"].remove(tipos)
                        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\tipos.json", 'w') as jf:
                            json.dump(self.tipos, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Tipo eliminado con exito",parent=self)
                            self.limpiar_panel(self.frame_dinamyc)
                            break


    def update_tipos(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\tipos.json", "r", encoding='utf-8') as self.file:
                self.tipos = json.load(self.file)

                seleccion = self.tablausuarios.selection()

                if seleccion:

                    for item in seleccion:
                        itemm = self.tablausuarios.index(item)

                        self.cliente_e.delete(0, tk.END)
                        self.cliente_e.insert(0, self.tipos["tipos"][itemm]["cliente"])
                        self.tipo.delete(0, tk.END)
                        self.tipo.insert(0, self.tipos["tipos"][itemm]["tipo"])
                        self.descripcion.delete(0, tk.END)
                        self.descripcion.insert(0,self.tipos["tipos"][itemm]["descripcion"])
                        self.tipo_action = "Actualizar"

## Atenciones ##

    def main_atenciones(self):
        self.formulario_atenciones()
        self.listar_atenciones()

    def clientes_e(self, event):
        animal = self.cliente_e.get()
        
    
    def formulario_atenciones(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="\uf0c9 REGISTRO DE ATENCIONES", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=30)
        
        labelatenciones = tk.Label(self.frame_dinamyc,text="Atenciones:", font=('Times',14))
        labelatenciones.place(x=70, y=100)

        self.atenciones = tk.Entry(self.frame_dinamyc , width=40)
        self.atenciones.place(x= 270, y=100)

        labelaprecio = tk.Label(self.frame_dinamyc,text="Precio:", font=('Times',14))
        labelaprecio.place(x=70, y=150)

        self.precio = tk.Entry(self.frame_dinamyc , width=40)
        self.precio.place(x= 270, y=150)


        btnguardar = tk.Button(self.frame_dinamyc, text="\uf0c7 GUARDAR", font=('Times',14), command=self.save_atenciones)
        btnguardar.place(x= 600, y= 120 )
    
    def listar_atenciones(self):
        tk.Label(self.frame_dinamyc,text="\uf00b LISTADO DE ATENCIONES", font=('Times',16),fg="#9fa8da").place(x=70, y=200)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("Precios"))
        self.tablausuarios.heading("#0", text="Atenciones")
        self.tablausuarios.heading("Precios", text="Precios")
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json", "r", encoding='utf-8') as self.file:
                self.atencione = json.load(self.file)
                for atencion in self.atencione["atenciones"]:
                    self.tablausuarios.insert("", "end", text=f'{atencion["atenciones"]}',values=(f'{atencion["precios"]}'))
        self.tablausuarios.place(x=70, y=250)
        btneliminar = tk.Button(self.frame_dinamyc, text="\uf0c7 Eliminar", font=('Times',14), command=self.delete_atenciones)
        btneliminar.place(x=70, y=520)
        btnupdate = tk.Button(self.frame_dinamyc, text="\uf0c7 Actualizar", font=('Times',14), command=self.update_atenciones)
        btnupdate.place(x=200, y=520)

    def save_atenciones(self):
        if self.atenciones.get() == "" or self.precio.get() == "":
            messagebox.showinfo('Info',"Debe llenar todos los campos",parent=self)
            return 
        else:
                with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json", "r", encoding='utf-8') as self.file:
                        self.atencione = json.load(self.file)

                        if self.tipo_action == "Actualizar":

                            for atencion in self.atencione["atenciones"]:
                                if atencion["atenciones"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                                    atencion["atenciones"] = self.atenciones.get()
                                    atencion["precios"] = self.precio.get()
                                
                                    with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json", 'w') as jf: 
                                        json.dump(self.atencione, jf, indent=4, ensure_ascii=True)
                                        messagebox.showinfo('Info',"Atencion actualizada con exito",parent=self)
                            
                                        self.limpiar_panel(self.frame_dinamyc)
                    
                        else:
                            self.atencione["atenciones"].append({
                                            'atenciones': self.atenciones.get(),
                                            'precios': self.precio.get()

                                            })
                            with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json", 'w') as jf: 
                                json.dump(self.atencione, jf, indent=4, ensure_ascii=True)
                                messagebox.showinfo('Info',"Atencion registrada con exito",parent=self)
                                self.limpiar_panel(self.frame_dinamyc) 


    def delete_atenciones(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json", "r", encoding='utf-8') as self.file:
                self.atencione = json.load(self.file)
                for atencion in self.atencione["atenciones"]:
                    if atencion["atenciones"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                        self.atencione["atenciones"].remove(atencion)
                        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json", 'w') as jf:
                            json.dump(self.atencione, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Atencion eliminada con exito",parent=self)
                            self.limpiar_panel(self.frame_dinamyc)
                            break


    def update_atenciones(self):
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json", "r", encoding='utf-8') as self.file:
                self.atencione = json.load(self.file)

                seleccion = self.tablausuarios.selection()

                if seleccion:

                    for item in seleccion:
                        itemm = self.tablausuarios.index(item)

                        self.atenciones.delete(0, tk.END)
                        self.atenciones.insert(0, self.atencione["atenciones"][itemm]["atenciones"])
                        self.precio.delete(0, tk.END)
                        self.precio.insert(0, self.atencione["atenciones"][itemm]["precios"])

                        self.tipo_action = "Actualizar"
        

    def limpiar_panel(self,panel):
    # Función para limpiar el contenido del panel
        for widget in panel.winfo_children():
            widget.destroy()
    def logout(self):
        self.destroy()