import tkinter as tk
import json
from tkinter import messagebox,ttk
import util.generic as utl
class PVentas(tk.Tk):
    def __init__(self, name="", username="", email=""):
        self.name = name
        self.username = username
        self.email = email
        super().__init__()
        self.title("Panel Ventas")
        self.resizable(False, False)
        # Obtener las dimensiones de la pantalla
        self.ancho_pantalla = self.winfo_screenwidth() #método para obtener Ancho
        self.alto_pantalla = self.winfo_screenheight() #método para obtener Alto

        # Establecer el tamaño completo de la ventana
        self.geometry(f"{self.ancho_pantalla}x{self.alto_pantalla}")
        
        menubar = tk.Menu(self)  

        menuclientes = tk.Menu(menubar, tearoff=0)
        menuclientes.add_command(label="Confirmar Venta", command=self.confirmar_form)  
        menuclientes.add_command(label="Listar Ventas", command=self.listar_venta)  
        menubar.add_cascade(label="Ventas", menu=menuclientes)
        self.config(menu=menubar)

        # frame user info

        self.frame_user_info = tk.Frame(self, bd=0,relief=tk.SOLID, width=200)
        self.frame_user_info.pack(side=tk.LEFT, padx=4, pady=5,fill="y")
        texto=tk.Label(self.frame_user_info, text="PANEL VENTAS", font=('Times', 20))
        texto.pack(padx=20,pady=4)
        usrimg = utl.leer_imagen(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\imagenes\userinfo.png", (48, 48))
        self.imgusr=tk.Label(self.frame_user_info, image=usrimg)
        self.imgusr.pack(padx=30,pady=4)
        texto1=tk.Label(self.frame_user_info, text=self.name, font=('Times', 14))
        texto1.pack(padx=40,pady=4)
        texto1=tk.Label(self.frame_user_info, text=self.email, font=('Times', 14))
        texto1.pack(padx=50,pady=4)
        
        #frame_data
        
        self.frame_data = tk.Frame(self, bd=0,relief=tk.SOLID, width=f"{self.ancho_pantalla-200}")
        self.frame_data.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)
        textobienvenida=tk.Label(self.frame_data, text="BIENVENIDO AL SISTEMA", font=('Times', 20))
        textobienvenida.pack(padx=20,pady=4)

        #frame_dinamyc
        self.frame_dinamyc = tk.Frame(self.frame_data, bd=0,relief=tk.SOLID, width=f"{self.ancho_pantalla-200}")
        self.frame_dinamyc.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)

    def seleccion_animal(self, event):

        self.seleccion = self.animal.get()

    def seleccion_atencion(self, event):

        self.seleccion2 = self.atencionn.get()

    def confirmar_form(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="REGISTRO DE VENTAS", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        
        labelnombre = tk.Label(self.frame_dinamyc,text="Clientes:", font=('Times',14))
        labelnombre.place(x=70, y=130)

        with open(r'C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\animales.json', 'r') as jf:
                cliente = json.load(jf)
        
        clientes = [animal["nombre"] for animal in cliente["animales"]]

        self.animal = ttk.Combobox(self.frame_dinamyc,
            values= clientes
        )
        self.animal.place(x= 220, y=130)
        self.animal.bind("<<ComboboxSelected>>", self.seleccion_animal)
        
        labelatencion = tk.Label(self.frame_dinamyc,text="Atencion:", font=('Times',14))
        labelatencion.place(x=70, y=160)

        with open(r'C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json', 'r') as jf:
            atencion = json.load(jf)

        atenciones = [atencion["atenciones"] for atencion in atencion["atenciones"]]

        self.atencionn = ttk.Combobox(self.frame_dinamyc,
            values= atenciones
        )
        self.atencionn.place(x= 220, y=160)
        self.atencionn.bind("<<ComboboxSelected>>", self.seleccion_atencion)
    

        btnguardar = tk.Button(self.frame_dinamyc, text="CONFIRMAR", font=('Times',14), command=self.save_venta)
        btnguardar.place(x=70, y=250)


    def listar_venta(self):
            self.limpiar_panel(self.frame_dinamyc)
            labelform = tk.Label(self.frame_dinamyc,text="LISTADO DE VENTAS", font=('Times',16),fg="#9fa8da")
            labelform.place(x=70, y=70)
            self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("atencion","precio"))
            self.tablausuarios.heading("#0", text="cliente")
            self.tablausuarios.heading("atencion", text="atencion")
            self.tablausuarios.heading("precio", text="precio")
            
            with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\ventas totales.json", "r", encoding='utf-8') as file:
                    ventas = json.load(file)
                    for ven in ventas["ventas"]:
                        self.tablausuarios.insert("", "end", text=f'{ven["cliente"]}',values=(f'{ven["atenciones"]}',f'{ven["precio"]}'))
            self.tablausuarios.place(x=70, y=100)
    
    def save_venta(self):

        with open(r'C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\atenciones.json', 'r') as jf:
            atencion = json.load(jf)

        precios = [animal["precios"] for animal in atencion["atenciones"]]

        index = self.atencionn.current()
        global precio_total
        precio_total = precios[index]

        
                
        with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\ventas totales.json", "r", encoding='utf-8') as file:
                ventas = json.load(file)

                ventas["ventas"].append({
                        'cliente': self.animal.get(),
                        'atenciones': self.atencionn.get(),
                        "precio": precio_total
                
                    })
                with open(r"C:\Users\USUARIO\Desktop\parcial sebastian\LoginApp\formularios\data\ventas totales.json", 'w') as jf: 
                    json.dump(ventas, jf, indent=4, ensure_ascii=True)
                    messagebox.showinfo('Info',"Venta registrada con exito",parent=self)
                
                    
    
    def limpiar_panel(self,panel):
    # Función para limpiar el contenido del panel
        for widget in panel.winfo_children():
            widget.destroy()