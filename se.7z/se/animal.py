class animal:
    def __init__ (self,nombre,peso):
        self.nombre = nombre 
        self.peso = peso 
    
    def imprimirnombre(self):
        print (f'el nombre del animal es:{self.nombre}')
    