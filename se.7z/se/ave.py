from animal import animal
class Ave (animal):
    def __init__(self,nombre,peso,nacimiento,propietario):
        super().__init__(nombre,peso)
        self.nacimiento = nacimiento
        self.propietario = propietario 
        
        def calcularedad (self):
            edad = 2024 - self.nacimiento
            if edad>=5
            print ("es mayor de edad")
            else:
                print("es menor de edad")
                        
ave1 = Ave('condor',18,2012,'tecnar')
ave1.calcularedad()
ave1.imprimirnombre()